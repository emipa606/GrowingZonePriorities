﻿namespace GrowingZonePriorities
{
	enum Priority
	{
		Low = 1,
		Normal = 2,
		Preferred = 3,
		Important = 4,
		Critical = 5
	}
}
