﻿namespace GrowingZonePriorities
{
	class PriorityIntHolder
	{
		public int Int = (int)Priority.Normal;

		public PriorityIntHolder(int Int)
		{
			this.Int = Int;
		}
	}
}
